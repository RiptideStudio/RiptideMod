using Terraria.ModLoader;

namespace RiptideMod
{
	public class RiptideMod : Mod
	{
		
    }
}